package system.front;

import system.core.GameSelector;

public class Test {

	public static void main(String[] args) {
		GameSelector.selectTableOnCUI(new ScannerForMultiThreadOnCUI());
	}

}
